<html>
<head>
	<link rel="stylesheet" href="dist/reveal.css">
	<link rel="stylesheet" href="dist/theme/white.css" id="theme">
</head>
<body>
	<div class="reveal">
		<div class="slides">
			<section>Slide 1</section>
			<section>Slide 2</section>
		</div>
	</div>
	<script src="dist/reveal.js"></script>
	<script>
		Reveal.initialize({/* config */});
	</script>
</body>
</html>

<section>
  <h1>Заголовок</h1>
  <h2>Под-заголовок</h2>
  <h3>Под-под-заголовок</h3>
  <h4>Под-под-под-заголовок</h4>
  <p>Тело слайда</p>
</section>

